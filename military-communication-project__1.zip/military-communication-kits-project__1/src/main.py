from QuantumCryptoToken import *

print(generateToken(10))